--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10 (Ubuntu 12.10-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.10 (Ubuntu 12.10-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tarea;
--
-- Name: tarea; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tarea WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'es_CL.UTF-8' LC_CTYPE = 'es_CL.UTF-8';


ALTER DATABASE tarea OWNER TO postgres;

\connect tarea

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: division_regional; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.division_regional (
    gid integer NOT NULL,
    nom_reg character varying(50),
    nom_prov character varying(20),
    cod_com character varying(5),
    nom_com character varying(30),
    cod_regi numeric,
    superficie numeric,
    poblac02 integer,
    pobl2010 integer,
    shape_leng numeric,
    shape_area numeric,
    geom public.geometry(MultiPolygon)
);


ALTER TABLE public.division_regional OWNER TO postgres;

--
-- Name: division_regional_gid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.division_regional_gid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.division_regional_gid_seq OWNER TO postgres;

--
-- Name: division_regional_gid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.division_regional_gid_seq OWNED BY public.division_regional.gid;


--
-- Name: dog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dog (
    id integer NOT NULL,
    name character varying(32),
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.dog OWNER TO postgres;

--
-- Name: dog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dog_id_seq OWNER TO postgres;

--
-- Name: dog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dog_id_seq OWNED BY public.dog.id;


--
-- Name: division_regional gid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.division_regional ALTER COLUMN gid SET DEFAULT nextval('public.division_regional_gid_seq'::regclass);


--
-- Name: dog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dog ALTER COLUMN id SET DEFAULT nextval('public.dog_id_seq'::regclass);


--
-- Data for Name: division_regional; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.division_regional (gid, nom_reg, nom_prov, cod_com, nom_com, cod_regi, superficie, poblac02, pobl2010, shape_leng, shape_area, geom) FROM stdin;
\.
COPY public.division_regional (gid, nom_reg, nom_prov, cod_com, nom_com, cod_regi, superficie, poblac02, pobl2010, shape_leng, shape_area, geom) FROM '$$PATH$$/3872.dat';

--
-- Data for Name: dog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dog (id, name, latitude, longitude) FROM stdin;
\.
COPY public.dog (id, name, latitude, longitude) FROM '$$PATH$$/3874.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/3730.dat';

--
-- Name: division_regional_gid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.division_regional_gid_seq', 23, true);


--
-- Name: dog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dog_id_seq', 1, false);


--
-- Name: division_regional division_regional_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.division_regional
    ADD CONSTRAINT division_regional_pkey PRIMARY KEY (gid);


--
-- Name: dog dog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dog
    ADD CONSTRAINT dog_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

